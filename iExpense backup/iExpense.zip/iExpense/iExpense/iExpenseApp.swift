//
//  iExpenseApp.swift
//  iExpense
//
//  Created by Антон Баскаков on 15.05.2024.
//

import SwiftUI

@main
struct iExpenseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
